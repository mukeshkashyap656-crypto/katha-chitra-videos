"""Ramayan props and special characters (bow, quiver, arrows, Tataka, yakshi, forest bits)."""
import math, random, cairo
from chars import person, hexc, fill_stroke, ellipse, poly, limb, OL, CHARS

# ---------------- bow / quiver / arrow ----------------
def quiver_back(c, x, feet, H, side=1):
    """quiver behind the shoulder (drawn BEFORE the person)."""
    u = H / 5.0; top = feet - H
    qx = x + side * 0.42 * u; qy = top + 0.95 * u
    c.save(); c.translate(qx, qy); c.rotate(side * 0.35)
    for k, dx in enumerate((-0.07, 0.0, 0.07)):  # arrow fletchings
        poly(c, [(dx * u - 0.04 * u, -0.25 * u), (dx * u, -0.42 * u), (dx * u + 0.04 * u, -0.25 * u)]); fill_stroke(c, "#f6f0e2" if k != 1 else "#d9342b", 2.5)
    c.rectangle(-0.13 * u, -0.25 * u, 0.26 * u, 1.05 * u); fill_stroke(c, "#8a4a22", 4)
    for yy in (-0.12, 0.6):
        c.rectangle(-0.13 * u, yy * u, 0.26 * u, 0.07 * u); fill_stroke(c, "#f2c230", 3)
    c.restore()

def bow(c, hx, hy, u, pull=None, side=1, rest=False):
    """bow held at (hx,hy). side=1 bow bends toward screen right. pull=(px,py) string pulled point."""
    L = 1.05 * u
    if rest:   # held down by the side, slanted
        c.save(); c.translate(hx, hy); c.rotate(side * 0.25)
        top, bot = (0, -L), (0, L)
        c.move_to(*top); c.curve_to(side * 0.38 * u, -0.5 * L, side * 0.38 * u, 0.5 * L, *bot)
        c.set_source_rgb(*OL); c.set_line_width(0.09 * u + 6); c.stroke_preserve(); c.set_source_rgb(*hexc("#8a4a22")); c.set_line_width(0.09 * u); c.stroke()
        c.move_to(*top); c.line_to(*bot); c.set_source_rgb(0.95, 0.9, 0.8); c.set_line_width(2.5); c.stroke()
        c.arc(0, 0, 0.07 * u, 0, 6.3); fill_stroke(c, "#f2c230", 3)
        c.restore(); return
    top = (hx - side * 0.25 * u, hy - L); bot = (hx - side * 0.25 * u, hy + L)
    c.move_to(*top); c.curve_to(hx + side * 0.35 * u, hy - 0.55 * L, hx + side * 0.35 * u, hy + 0.55 * L, *bot)
    c.set_source_rgb(*OL); c.set_line_width(0.1 * u + 6); c.stroke_preserve(); c.set_source_rgb(*hexc("#8a4a22")); c.set_line_width(0.1 * u); c.stroke()
    for p in (top, bot):
        c.arc(p[0], p[1], 0.05 * u, 0, 6.3); fill_stroke(c, "#f2c230", 2.5)
    sp = pull if pull else ((top[0] + bot[0]) / 2, hy)
    c.move_to(*top); c.line_to(*sp); c.line_to(*bot); c.set_source_rgb(0.98, 0.94, 0.85); c.set_line_width(3); c.stroke()
    return sp

def arrow(c, x0, y0, x1, y1, col="#8a4a22", glow=False):
    ang = math.atan2(y1 - y0, x1 - x0); ln = math.hypot(x1 - x0, y1 - y0)
    c.save(); c.translate(x1, y1); c.rotate(ang)
    if glow:
        g = cairo.LinearGradient(-ln, 0, 0, 0); g.add_color_stop_rgba(0, 1, 0.85, 0.3, 0); g.add_color_stop_rgba(1, 1, 0.9, 0.4, 0.8)
        c.set_source(g); c.rectangle(-ln, -10, ln, 20); c.fill()
    c.move_to(-ln, 0); c.line_to(-14, 0); c.set_source_rgb(*OL); c.set_line_width(8); c.stroke_preserve(); c.set_source_rgb(*hexc(col)); c.set_line_width(4); c.stroke()
    poly(c, [(0, 0), (-22, -9), (-22, 9)]); fill_stroke(c, "#d8d8d8", 3)
    for s in (-1, 1):
        poly(c, [(-ln, 0), (-ln + 18, s * 12), (-ln + 30, s * 12), (-ln + 14, 0)]); fill_stroke(c, "#f6f0e2", 2.5)
    c.restore()

def flash(c, x, y, r, a):
    if a <= 0: return
    g = cairo.RadialGradient(x, y, 0, x, y, r); g.add_color_stop_rgba(0, 1, 1, 0.9, a); g.add_color_stop_rgba(0.4, 1, 0.9, 0.5, a * 0.6); g.add_color_stop_rgba(1, 1, 0.8, 0.3, 0)
    c.set_source(g); c.arc(x, y, r, 0, 6.3); c.fill()
    c.save(); c.translate(x, y)
    for k in range(10):
        a_ = k * math.pi / 5
        poly(c, [(math.cos(a_ - 0.08) * r * 0.2, math.sin(a_ - 0.08) * r * 0.2), (math.cos(a_) * r * 0.8, math.sin(a_) * r * 0.8), (math.cos(a_ + 0.08) * r * 0.2, math.sin(a_ + 0.08) * r * 0.2)])
        c.set_source_rgba(1, 1, 0.85, a); c.fill()
    c.restore()

def prince(c, name, x, feet, H, aim=0.0, pull=0.0, bowrest=True, side=1, **kw):
    """Ram / Lakshman with quiver and bow. aim 0..1 raises bow arm to shoot toward `side`; pull 0..1 draws the string."""
    u = H / 5.0
    quiver_back(c, x, feet, H, side=-side)
    if aim > 0:
        e = aim
        bow_arm = (side * (0.12 + e * 1.45), side * (-0.05 + e * 0.05))
        draw_arm = (side * (0.15 + e * 1.6), -side * (0.1 + e * (2.0 + pull * 0.6)))
        if side > 0: arms = (draw_arm[0], draw_arm[1], bow_arm[0], bow_arm[1])
        else: arms = (bow_arm[0], bow_arm[1], draw_arm[0], draw_arm[1])
    else:
        arms = kw.pop("arms", None) or ((0.12, 0.05, -0.12, -0.05))
    kw.pop("arms", None)
    info = person(c, name, x, feet, H, arms=arms, **kw)
    hands = info["hands"]
    if aim > 0:
        bh = hands[1] if side > 0 else hands[0]
        dh = hands[0] if side > 0 else hands[1]
        bow(c, bh[0], bh[1], u, pull=dh if pull > 0.05 else None, side=side)
        ellipse(c, bh[0], bh[1], 0.11 * u, 0.11 * u); fill_stroke(c, CHARS[name]["skin"], 4)
        info["bowhand"] = bh; info["drawhand"] = dh
    elif bowrest:
        bh = hands[1] if side > 0 else hands[0]
        bow(c, bh[0], bh[1] - 0.1 * u, u, side=side, rest=True)
        ellipse(c, bh[0], bh[1], 0.11 * u, 0.11 * u); fill_stroke(c, CHARS[name]["skin"], 4)
    return info

# ---------------- Tataka ----------------
TK = dict(skin="#6b5470", skin2="#4e3c55", hair="#120a0e", cloth="#1c1418", cloth2="#8e1b2b", eye="#ff3020")

def tataka(c, x, feet, H, t=0.0, state="stand", arms_up=0.0, mouth=0.6, alpha=1.0, lean=0.0, hit=0.0, shadow=0.0):
    """state: stand/charge/recoil. shadow: 0..1 turns her into a black silhouette with red eyes."""
    u = H / 5.0
    c.push_group()
    top = feet - H
    c.save(); c.translate(x, feet); c.rotate(lean); c.translate(-x, -feet)
    hx, hy = x, top + 0.62 * u
    # dark red-black glow
    g = cairo.RadialGradient(x, top + 2.0 * u, 0.5 * u, x, top + 2.0 * u, 3.2 * u)
    g.add_color_stop_rgba(0, 0.55, 0.05, 0.08, 0.55); g.add_color_stop_rgba(1, 0.2, 0, 0.05, 0)
    c.set_source(g); c.arc(x, top + 2.0 * u, 3.2 * u, 0, 6.3); c.fill()
    # wild hair mass behind
    rnd = random.Random(7)
    c.move_to(hx - 1.0 * u, hy + 1.2 * u)
    n = 22
    for k in range(n + 1):
        a = math.pi * (1.05 + k / n * 0.9 + 0.0)
        a = math.pi * 0.95 + (k / n) * math.pi * 1.1
        rr = (1.05 + 0.35 * ((k % 2) * 1.0)) * u + math.sin(t * 6 + k) * 0.05 * u
        c.line_to(hx + math.cos(a) * rr, hy - 0.05 * u + math.sin(a) * rr * 0.95)
    c.line_to(hx + 1.0 * u, hy + 1.2 * u)
    for k in range(6):
        xx = hx + 1.0 * u - k * 0.4 * u
        c.line_to(xx - 0.2 * u, hy + (1.45 + 0.15 * (k % 2)) * u)
    c.close_path(); fill_stroke(c, TK["hair"], 5)
    # legs
    for s in (-1, 1):
        limb(c, [(x + s * 0.32 * u, top + 3.4 * u), (x + s * 0.42 * u, feet - 0.1 * u)], 0.32 * u, TK["skin"])
        ellipse(c, x + s * 0.45 * u, feet - 0.05 * u, 0.24 * u, 0.09 * u); fill_stroke(c, TK["skin2"], 4)
    # tattered skirt
    pts = [(x - 0.7 * u, top + 2.45 * u), (x + 0.7 * u, top + 2.45 * u)]
    for k in range(9):
        xx = x + 0.95 * u - k * 0.2375 * u
        yy = top + (3.7 + (0.25 if k % 2 else 0)) * u
        pts.append((xx, yy))
    poly(c, pts); fill_stroke(c, TK["cloth"], 5)
    c.move_to(x - 0.72 * u, top + 2.55 * u); c.line_to(x + 0.72 * u, top + 2.55 * u)
    c.set_source_rgb(*hexc(TK["cloth2"])); c.set_line_width(0.12 * u); c.stroke()
    # torso
    sh_y = top + 1.35 * u; sw = 0.82 * u
    c.move_to(x - sw, sh_y + 0.1 * u); c.curve_to(x - sw, sh_y - 0.1 * u, x + sw, sh_y - 0.1 * u, x + sw, sh_y + 0.1 * u)
    c.curve_to(x + sw * 1.05, sh_y + 0.6 * u, x + 0.72 * u, top + 2.2 * u, x + 0.7 * u, top + 2.5 * u)
    c.line_to(x - 0.7 * u, top + 2.5 * u); c.curve_to(x - 0.72 * u, top + 2.2 * u, x - sw * 1.05, sh_y + 0.6 * u, x - sw, sh_y + 0.1 * u)
    c.close_path(); fill_stroke(c, TK["skin"], 5)
    # ragged wrap over chest
    poly(c, [(x - 0.78 * u, sh_y + 0.35 * u), (x + 0.78 * u, sh_y + 0.35 * u), (x + 0.74 * u, sh_y + 0.85 * u), (x + 0.4 * u, sh_y + 0.75 * u),
             (x + 0.1 * u, sh_y + 0.9 * u), (x - 0.25 * u, sh_y + 0.76 * u), (x - 0.55 * u, sh_y + 0.9 * u), (x - 0.75 * u, sh_y + 0.8 * u)])
    fill_stroke(c, TK["cloth"], 4)
    c.move_to(x - 0.78 * u, sh_y + 0.42 * u); c.line_to(x + 0.78 * u, sh_y + 0.42 * u); c.set_source_rgb(*hexc(TK["cloth2"])); c.set_line_width(0.07 * u); c.stroke()
    # arms
    if state != "recoil":
        for s in (-1, 1):
            a1 = s * (0.35 + arms_up * 2.3) + math.sin(t * 5 + s) * 0.05
            a2 = s * (0.2 + arms_up * 0.3)
            sx, sy = x + s * sw * 0.9, sh_y + 0.15 * u
            ex, ey = sx + math.sin(a1) * 0.95 * u, sy + math.cos(a1) * 0.95 * u
            hx2, hy2 = ex + math.sin(a1 + a2) * 0.9 * u, ey + math.cos(a1 + a2) * 0.9 * u
            limb(c, [(sx, sy), (ex, ey)], 0.3 * u, TK["skin"]); limb(c, [(ex, ey), (hx2, hy2)], 0.26 * u, TK["skin"])
            # clawed hand
            c.arc(hx2, hy2, 0.17 * u, 0, 6.3); fill_stroke(c, TK["skin2"], 4)
            ang = math.atan2(hy2 - ey, hx2 - ex)
            for k in (-0.6, 0, 0.6):
                aa = ang + k
                poly(c, [(hx2 + math.cos(aa - 0.15) * 0.14 * u, hy2 + math.sin(aa - 0.15) * 0.14 * u), (hx2 + math.cos(aa) * 0.34 * u, hy2 + math.sin(aa) * 0.34 * u),
                         (hx2 + math.cos(aa + 0.15) * 0.14 * u, hy2 + math.sin(aa + 0.15) * 0.14 * u)])
                fill_stroke(c, "#e8dcc0", 2.5)
    # neck + head
    poly(c, [(hx - 0.2 * u, hy + 0.3 * u), (hx + 0.2 * u, hy + 0.3 * u), (hx + 0.22 * u, sh_y + 0.05 * u), (hx - 0.22 * u, sh_y + 0.05 * u)]); fill_stroke(c, TK["skin"], 4)
    rx, ry = 0.5 * u, 0.56 * u
    c.move_to(hx - rx, hy - 0.1 * u)
    c.curve_to(hx - rx * 1.05, hy - ry * 1.1, hx + rx * 1.05, hy - ry * 1.1, hx + rx, hy - 0.1 * u)
    c.curve_to(hx + rx * 1.02, hy + ry * 0.6, hx + 0.3 * u, hy + ry * 1.05, hx, hy + ry * 1.08)
    c.curve_to(hx - 0.3 * u, hy + ry * 1.05, hx - rx * 1.02, hy + ry * 0.6, hx - rx, hy - 0.1 * u)
    c.close_path(); fill_stroke(c, TK["skin"], 5)
    # hair fringe over forehead (jagged)
    pts = [(hx - rx * 1.05, hy - 0.05 * u)]
    for k in range(8):
        pts.append((hx - rx + (k + 0.5) * rx / 4, hy - ry * (0.45 if k % 2 else 0.7)))
    pts += [(hx + rx * 1.05, hy - 0.05 * u), (hx + rx, hy - ry * 1.05), (hx - rx, hy - ry * 1.05)]
    poly(c, pts); fill_stroke(c, TK["hair"], 4)
    # angry brows
    for s in (-1, 1):
        poly(c, [(hx + s * 0.38 * u, hy - 0.3 * u), (hx + s * 0.05 * u, hy - 0.12 * u), (hx + s * 0.07 * u, hy - 0.05 * u), (hx + s * 0.38 * u, hy - 0.2 * u)])
        fill_stroke(c, TK["hair"], 3)
    # glowing red eyes
    for s in (-1, 1):
        ex, ey = hx + s * 0.2 * u, hy - 0.02 * u
        g = cairo.RadialGradient(ex, ey, 0, ex, ey, 0.22 * u); g.add_color_stop_rgba(0, 1, 0.3, 0.1, 0.8); g.add_color_stop_rgba(1, 1, 0, 0, 0)
        c.set_source(g); c.arc(ex, ey, 0.22 * u, 0, 6.3); c.fill()
        ellipse(c, ex, ey, 0.11 * u, 0.065 * u); fill_stroke(c, "#ffd23a", 3)
        ellipse(c, ex, ey, 0.04 * u, 0.055 * u); c.set_source_rgb(*hexc("#c01010")); c.fill()
    # broad nose
    c.move_to(hx - 0.1 * u, hy + 0.17 * u); c.curve_to(hx - 0.13 * u, hy + 0.08 * u, hx + 0.13 * u, hy + 0.08 * u, hx + 0.1 * u, hy + 0.17 * u)
    c.set_source_rgb(*OL); c.set_line_width(4); c.stroke()
    # mouth: roaring (open) with fangs
    my = hy + 0.36 * u; mw = 0.24 * u; mh = (0.04 + 0.16 * mouth) * u
    ellipse(c, hx, my, mw, mh); fill_stroke(c, "#3a0808", 4)
    for s in (-1, 1):
        poly(c, [(hx + s * 0.16 * u, my - mh * 0.9), (hx + s * 0.12 * u, my - mh * 0.9 + 0.13 * u), (hx + s * 0.08 * u, my - mh * 0.9)]); fill_stroke(c, "#f6f0e2", 2.5)
        poly(c, [(hx + s * 0.1 * u, my + mh * 0.9), (hx + s * 0.07 * u, my + mh * 0.9 - 0.08 * u), (hx + s * 0.04 * u, my + mh * 0.9)]); fill_stroke(c, "#f6f0e2", 2)
    c.restore()
    # hit flash tint
    if hit > 0:
        c.set_operator(cairo.OPERATOR_ATOP); c.set_source_rgba(1, 0.95, 0.8, hit * 0.3); c.paint(); c.set_operator(cairo.OPERATOR_OVER)
    if shadow > 0:
        c.set_operator(cairo.OPERATOR_ATOP); c.set_source_rgba(0.03, 0.01, 0.02, shadow); c.paint(); c.set_operator(cairo.OPERATOR_OVER)
    c.pop_group_to_source(); c.paint_with_alpha(alpha)
    if shadow > 0.3:   # eyes stay glowing in the shadow
        c.save(); c.translate(x, feet); c.rotate(lean); c.translate(-x, -feet)
        for s in (-1, 1):
            ex, ey = hx + s * 0.2 * u, hy - 0.02 * u
            g = cairo.RadialGradient(ex, ey, 0, ex, ey, 0.3 * u); g.add_color_stop_rgba(0, 1, 0.2, 0.1, alpha); g.add_color_stop_rgba(1, 1, 0, 0, 0)
            c.set_source(g); c.arc(ex, ey, 0.3 * u, 0, 6.3); c.fill()
            ellipse(c, ex, ey, 0.1 * u, 0.06 * u); c.set_source_rgba(1, 0.25, 0.15, alpha); c.fill()
        c.restore()
    return dict(head=(hx, hy), chest=(x, top + 1.9 * u), u=u)

# ---------------- yakshi (Tataka before the curse), only in a memory inset ----------------
def yakshi(c, x, feet, H, t=0.0):
    CHARS.setdefault("yakshi", dict(kind="f", skin="#e8b48a", hair="#1a0f0a", blouse="#2f8a4a", saree="#d9342b", border="#f2c230", bindi=True, jewel=True))
    g = cairo.RadialGradient(x, feet - H * 0.6, 0, x, feet - H * 0.6, H * 0.7)
    g.add_color_stop_rgba(0, 1, 0.92, 0.6, 0.6); g.add_color_stop_rgba(1, 1, 0.9, 0.5, 0)
    c.set_source(g); c.arc(x, feet - H * 0.6, H * 0.7, 0, 6.3); c.fill()
    return person(c, "yakshi", x, feet, H, arms=(0.3, -1.2, -0.3, 1.2), emo="smile")
