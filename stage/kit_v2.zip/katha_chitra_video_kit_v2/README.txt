Katha Chitra video kit v2 (Bhag 4, 20 Nov 2026)
kc.py     - sancha: border, title+sawaal, logo, chip, shabd-shabd subtitle, subscribe widget, lip-sync, sound effects, music
chars.py  - saare insaani characters (Ram, Lakshman, Vishwamitra, Vasishtha, Dasharatha, darbari...)
rprops.py - dhanush, tarkash, baan, chamak, Tataka, yakshi
bgs.py    - jungle (dar/sandhya/khilta), Ganga aur naav, dhool, patthar, kiranein, panchhi
ep4.py    - Bhag 4 ki kahani: lines, shots, cover, audio, render
Awaaz: Composio workbench mein edge-tts (hi-IN-MadhurNeural) -> zip -> Google Drive (Composio) -> Drive MCP se download -> vo/
Chalana: python3 ep4.py audio ; python3 ep4.py part a b out.mp4 (2 hisse) ; concat ; mux
