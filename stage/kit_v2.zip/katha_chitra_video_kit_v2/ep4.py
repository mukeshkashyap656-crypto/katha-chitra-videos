"""Ramayan Bhag 4 - Tataka Vadh (Valmiki Bal Kand 24-26)."""
import sys, os, math, json, subprocess, random
import numpy as np, cairo
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import kc
from kc import W, H, FPS, SX, SY, SW, SH, PY, ease, blink
from chars import person, hexc, fill_stroke, ellipse, poly, OL
import rprops as P, bgs as B

D = os.path.dirname(os.path.abspath(__file__))
TITLE = "रामायण · भाग 4 · ताड़का वध"
QUESTION = "क्या राम ने एक स्त्री पर बाण चलाया?"
NAMES = {"V": "महर्षि विश्वामित्र", "R": "श्रीराम", "G": "इन्द्र और देवता"}
KEYS = ["श्रीराम", "स्त्री", "गंगा", "डरावना", "ताड़का", "हज़ार", "हाथियों", "यक्षी", "शाप", "आदमखोर", "राक्षसी", "टंकार", "काँप",
        "शक्ति", "धूल", "तूफ़ान", "पत्थर", "हाथ", "नाक", "कान", "माया", "गायब", "संध्या", "मारो", "आवाज़", "छाती", "साधु", "दिव्य", "अस्त्र", "जय", "श्री"]
HS = 430   # human height (everyone same)

LINES = {l["id"]: l for l in json.load(open(f"{D}/vo/lines.json"))}
SEQ = [("n01", 0.3), ("n02", 0.25), ("v03", 0.25), ("n04", 0.25), ("n05", 0.25), ("n06", 0.55), ("r07", 0.35), ("n08", 0.25),
       ("n09", 0.25), ("n10", 0.25), ("v11", 0.25), ("n12", 0.25), ("n13", 0.3), ("g14", 0.6), ("n15", 0.3), ("n16", 0.3)]
T = {}; t = 0.0
for lid, gap in SEQ:
    t += gap; T[lid] = t
    L = LINES[lid]; L["len"] = L["words"][-1][0] + L["words"][-1][1] + 0.12
    t += L["len"]
END_SPEECH = t
TOTAL = t + 1.7
NF = int(math.ceil(TOTAL * FPS))
def WT(lid, k): return T[lid] + LINES[lid]["words"][k][0]
def WE(lid, k): return T[lid] + LINES[lid]["words"][k][0] + LINES[lid]["words"][k][1]

# ---- lip-sync tracks (from audio if available, else from word timings) ----
MOUTH = {}
for lid, L in LINES.items():
    p = f"{D}/vo/{lid}.mp3"
    if L["spk"] in "VR" and os.path.exists(p):
        MOUTH[lid] = kc.mouth_track(kc.load_audio(p))
def mouth(lid, t):
    lt = t - T[lid]
    if lt < 0 or lt > LINES[lid]["len"]: return "X"
    if lid in MOUTH:
        k = int(lt * FPS); return MOUTH[lid][min(k, len(MOUTH[lid]) - 1)]
    return kc.mouth_from_words(LINES[lid]["words"], lt)

# ---------------- positions (battle ground) ----------------
LX, RX, VX, VF, TX, TF, TH = 120, 405, 262, 1000, 780, 1185, 700

def tataka_state(t):
    """story state of Tataka at time t (shared by all battle shots)."""
    st = dict(x=TX, feet=TF, alpha=1.0, shadow=0.0, arms=0.9, mouth=0.8, lean=0.0, hit=0.0, state="stand")
    if t < WT("n06", 2):
        p = ease((t - T["n06"]) / 0.9); st["shadow"] = 1.0
    if t >= WT("n09", 3):  # hands cut
        st["state"] = "recoil"; st["arms"] = 0
    h1 = WT("n09", 3); h2 = WT("n09", 7)
    for hh in (h1, h2):
        if hh - 0.05 < t < hh + 0.4: st["hit"] = max(st["hit"], 1 - (t - hh) / 0.45); st["lean"] = -0.12 * (1 - (t - hh) / 0.45)
    if T["n10"] <= t < WT("n12", 10):     # maya: vanished
        p = ease((t - T["n10"] - 0.3) / 1.0); st["alpha"] = 1 - p
        if t >= T["v11"]: st["alpha"] = 0
    if WT("n12", 10) <= t:                # reappears charging
        p = ease((t - WT("n12", 10)) / 0.5); st["alpha"] = p; st["lean"] = 0.18 * p; st["x"] = TX - 60 * ease((t - WT("n12", 10)) / 1.2)
        st["mouth"] = 1.0
    hit = WT("n12", 15)
    if hit - 0.05 < t:
        st["hit"] = max(0, 1 - (t - hit) / 0.6) if t < hit + 0.6 else 0
    fall = T["n13"] + 0.3
    if t >= fall:
        p = ease((t - fall) / 0.8); st["lean"] = 0.18 + 1.4 * p; st["mouth"] = 0.5 * (1 - p); st["x"] = TX - 60 + 100 * p
    return st

def draw_tataka(c, t, **over):
    st = tataka_state(t); st.update(over)
    if st["alpha"] <= 0.01: return None
    return P.tataka(c, st["x"], st["feet"], TH, t=t, state=st["state"], arms_up=st["arms"], mouth=st["mouth"], alpha=st["alpha"],
                    lean=st["lean"], hit=st["hit"], shadow=st["shadow"])

OVER = []
def overlay(fn): OVER.append(fn)

# ---------------- shots ----------------
# each shot: (start, chip, draw_fn, camera keyframes [(lt, zoom, cx, cy)])
def cam_at(keys, lt):
    if lt <= keys[0][0]: k = keys[0]; return k[1], k[2], k[3]
    for a, b in zip(keys, keys[1:]):
        if a[0] <= lt <= b[0]:
            p = ease((lt - a[0]) / max(1e-6, b[0] - a[0]))
            return tuple(a[i] + (b[i] - a[i]) * p for i in (1, 2, 3))
    k = keys[-1]; return k[1], k[2], k[3]

def s_hook(c, t, lt):
    B.forest(c, t, mood=1.0)
    st = tataka_state(T["n06"]); P.tataka(c, TX, TF, TH, t=t, arms_up=0.9, mouth=0.8, shadow=1.0, alpha=min(1, lt / 0.8))
    P.prince(c, "ram", RX, 1200, HS, emo="firm", look=0.9, aim=1.0, pull=ease(lt / 1.6), side=1, blink=False)

def s_ganga(c, t, lt):
    B.ganga(c, t)
    bx = 420 + lt * 55; bob = math.sin(t * 2.2) * 6
    for x, n in ((bx + 210, "vishwamitra2"), (bx, "ram"), (bx - 210, "lakshman")):
        if n == "vishwamitra2":
            person(c, n, x, 1020 + bob, HS, pose="sit", look=0.8, emo="neutral", arms=(-0.15, 2.1, 0.15, -2.1), prop="none", blink=blink(t, 0.3))
        else:
            P.prince(c, n, x, 1020 + bob, HS, pose="sit", look=0.8, emo="neutral", arms=(-0.15, 2.1, 0.15, -2.1), bowrest=False, blink=blink(t, x * 0.01))
    B.boat_front(c, bx, 1060 + bob, 640)

def walker(c, name, x, feet, t, look, emo, ph):
    bob = abs(math.sin(t * 6 + ph)) * 8
    if name == "vishwamitra2":
        person(c, name, x, feet - bob, HS, look=look, emo=emo, arms=(0.12 + math.sin(t * 6 + ph) * 0.15, 0.05, -0.12, -0.05), blink=blink(t, ph))
    else:
        P.prince(c, name, x, feet - bob, HS, look=look, emo=emo, side=1, arms=(0.12 - math.sin(t * 6 + ph) * 0.15, 0.05, -0.12, -0.05), blink=blink(t, ph))

def s_enter(c, t, lt):
    B.forest(c, t, mood=0.0)
    p = min(1.0, lt / 2.4)
    walker(c, "lakshman", -140 + 300 * ease(p), 1200, t, 0.8, "worry", 0.0)
    walker(c, "ram", 60 + 330 * ease(p), 1200, t, 0.8, "worry", 1.0)
    walker(c, "vishwamitra2", 260 + 380 * ease(p), 1200, t, 0.8, "stern", 2.0)

def standing_group(c, t, emo_r="worry", emo_l="worry", vm_mouth="X", vm_emo="stern", vm_arms=None, vm_look=-0.8, r_look=0.8):
    P.prince(c, "lakshman", 150, 1200, HS, emo=emo_l, look=0.8, side=1, blink=blink(t, 0.4))
    P.prince(c, "ram", 390, 1200, HS, emo=emo_r, look=r_look, side=1, blink=blink(t, 1.3))
    person(c, "vishwamitra2", 660, 1200, HS, emo=vm_emo, look=vm_look, mouth=vm_mouth, blink=blink(t, 2.2),
           arms=vm_arms or (0.12, 0.05, -0.12, -0.05))

def s_vm_tells(c, t, lt):
    B.forest(c, t, mood=0.15)
    talking = T["v03"] <= t < T["v03"] + LINES["v03"]["len"]
    standing_group(c, t, vm_mouth=mouth("v03", t), vm_arms=(0.12, 0.05, 1.5, -0.4) if talking else None, vm_look=0.6)
    # strength counter icon
    a0 = WT("v03", 6)
    if t > a0 - 0.1:
        a = ease((t - a0 + 0.1) / 0.3); n = int(1000 * ease((t - a0) / 0.9))
        overlay(lambda c: elephant_counter(c, 560, 170, a, n))

def elephant_counter(c, x, y, a, n):
    c.save(); c.translate(x, y); c.scale(0.6 + 0.4 * a, 0.6 + 0.4 * a)
    c.push_group()
    c.rectangle(-230, -80, 460, 160); c.set_source_rgba(0.1, 0.03, 0.03, 0.85); c.fill_preserve(); c.set_source_rgb(*hexc("#f2c230")); c.set_line_width(4); c.stroke()
    # elephant icon
    ellipse(c, -140, 0, 62, 42); fill_stroke(c, "#9a9aa8", 4)
    c.arc(-190, -18, 30, 0, 6.3); fill_stroke(c, "#9a9aa8", 4)
    c.move_to(-212, -5); c.curve_to(-235, 30, -222, 55, -205, 60); c.set_source_rgb(*OL); c.set_line_width(14); c.stroke_preserve(); c.set_source_rgb(*hexc("#9a9aa8")); c.set_line_width(8); c.stroke()
    for dx in (-175, -150, -120, -100):
        c.rectangle(dx, 30, 16, 32); fill_stroke(c, "#9a9aa8", 3)
    c.arc(-198, -26, 5, 0, 6.3); c.set_source_rgb(*OL); c.fill()
    kc.paint_center(c, kc.text_img(f"× {n}", 64, (255, 214, 60)), 70, -8)
    kc.paint_center(c, kc.text_img("हाथियों का बल", 28, (255, 244, 220), shadow=None), 70, 50)
    c.pop_group_to_source(); c.paint_with_alpha(a); c.restore()

def s_curse(c, t, lt):
    B.forest(c, t, mood=0.25)
    standing_group(c, t, emo_r="worry", emo_l="worry", vm_emo="stern", vm_look=-0.7)
    # memory inset (round frame)
    a = ease(lt / 0.4) * (1 - ease((t - (T["n04"] + LINES["n04"]["len"] - 0.1)) / 0.3))
    if a <= 0: return
    overlay(lambda c: curse_inset(c, t, a))

def curse_inset(c, t, a):
    cx, cy, r = 500, 400, 250
    c.save(); c.push_group()
    c.arc(cx, cy, r, 0, 6.3); c.clip()
    curse = WT("n04", 9)
    if t < curse:
        B.sky(c, hexc("#fbe3a8"), hexc("#f5c873"), 1220)
        P.yakshi(c, cx, cy + 230, 420, t)
    else:
        B.sky(c, hexc("#2a0a10"), hexc("#5a1018"), 1220)
        P.tataka(c, cx, cy + 300, 560, t=t, arms_up=0.6, mouth=0.7, shadow=1 - ease((t - curse - 0.6) / 0.8))
    P.flash(c, cx, cy, 300, 1 - abs(t - curse) / 0.3 if abs(t - curse) < 0.3 else 0)
    c.reset_clip()
    c.arc(cx, cy, r, 0, 6.3); c.set_source_rgb(*hexc("#f2c230")); c.set_line_width(12); c.stroke()
    c.arc(cx, cy, r + 10, 0, 6.3); c.set_source_rgb(*hexc("#8e1b2b")); c.set_line_width(6); c.stroke()
    c.pop_group_to_source(); c.paint_with_alpha(a); c.restore()
    if t > WT("n04", 6) - 0.2:
        kc.paint_center(c, kc.text_img("अगस्त्य मुनि का शाप", 40, (255, 214, 60)), 500, 700, a * ease((t - WT("n04", 6) + 0.2) / 0.3))

def s_twang(c, t, lt):
    tw = WT("n05", 6)
    shake = max(0, 1 - (t - tw) / 0.8) if t > tw else 0
    B.forest(c, t, mood=0.2, shake=shake)
    B.birds(c, t, tw)
    pull = ease((t - WT("n05", 2)) / 0.9) if t < tw else 0.0
    aim = ease((t - T["n05"]) / 0.5)
    person(c, "vishwamitra2", VX, VF, HS, emo="stern", look=0.6, blink=blink(t, 2.2))
    P.prince(c, "lakshman", LX, 1200, HS, emo="firm", look=0.8, side=1, blink=blink(t, 0.4))
    info = P.prince(c, "ram", RX, 1200, HS, emo="firm", look=0.9, aim=aim, pull=pull, side=1, blink=False)
    if t > tw and "bowhand" in info:
        bx, by = info["bowhand"]
        for k in range(3):
            r = 40 + ((t - tw) * 900 + k * 120) % 520
            c.arc(bx, by, r, 0, 6.3); c.set_source_rgba(1, 0.95, 0.7, max(0, 0.6 - r / 900) * shake); c.set_line_width(6); c.stroke()

def s_reveal(c, t, lt):
    B.forest(c, t, mood=1.0)
    rev = WT("n06", 2)
    if t < rev:
        p = ease(lt / 1.0); sc = 0.45 + 0.35 * p
        c.save(); c.translate(TX, TF - 220); c.scale(sc, sc); c.translate(-TX, -TF)
        P.tataka(c, TX, TF, TH, t=t, arms_up=0.9, mouth=0.9, shadow=1.0); c.restore()
    else:
        p = ease((t - rev) / 0.35); sc = 0.8 + 0.2 * p
        c.save(); c.translate(TX, TF - 220 * (1 - p)); c.scale(sc, sc); c.translate(-TX, -TF)
        P.tataka(c, TX, TF, TH, t=t, arms_up=0.9 + 0.1 * math.sin(t * 8), mouth=0.6 + 0.4 * abs(math.sin(t * 5)), shadow=1 - p); c.restore()
        P.flash(c, TX, TF - 400, 500, 0.6 * (1 - (t - rev) / 0.4) if t - rev < 0.4 else 0)
    person(c, "vishwamitra2", VX, VF, HS, emo="stern", look=0.7, blink=blink(t, 2.2))
    P.prince(c, "lakshman", LX, 1200, HS, emo="shock" if t > rev else "firm", look=0.8, side=1, blink=False)
    P.prince(c, "ram", RX, 1200, HS, emo="firm", look=0.9, side=1, blink=False)

def s_ram_speaks(c, t, lt):
    B.forest(c, t, mood=0.8)
    draw_tataka(c, t, arms=0.8 + 0.1 * math.sin(t * 6), mouth=0.5 + 0.4 * abs(math.sin(t * 4)))
    person(c, "vishwamitra2", VX, VF, HS, emo="stern", look=0.6, blink=blink(t, 2.2))
    P.prince(c, "lakshman", LX, 1200, HS, emo="worry", look=0.9, side=1, blink=blink(t, 0.4))
    P.prince(c, "ram", RX, 1200, HS, emo="firm", look=-0.9, side=1, mouth=mouth("r07", t), blink=blink(t, 1.1))

def battle(c, t, mood=0.9, dusk=0.0, dust=0.0, stones_t0=None, ram_aim=0.0, ram_pull=0.0, lak_aim=0.0, emo_r="firm", emo_l="firm",
           vm_emo="stern", vm_mouth="X", vm_arms=None, tk=True, ram_look=0.9):
    B.forest(c, t, mood=mood, dusk=dusk)
    if stones_t0 is not None: B.stones(c, t, stones_t0, n=16)
    info = {}
    if tk: info["tk"] = draw_tataka(c, t)
    person(c, "vishwamitra2", VX, VF, HS, emo=vm_emo, look=0.6, mouth=vm_mouth, arms=vm_arms, blink=blink(t, 2.2))
    info["lak"] = P.prince(c, "lakshman", LX, 1200, HS, emo=emo_l, look=0.9, side=1, aim=lak_aim, pull=lak_aim, blink=blink(t, 0.4))
    info["ram"] = P.prince(c, "ram", RX, 1200, HS, emo=emo_r, look=ram_look, side=1, aim=ram_aim, pull=ram_pull, blink=blink(t, 1.1))
    if dust > 0: B.dust(c, t, dust, cx=500, cy=850)
    return info

def s_dust(c, t, lt):
    d = ease(lt / 0.6)
    battle(c, t, mood=0.9, dust=d, stones_t0=WT("n08", 4) - 0.4, emo_r="worry", emo_l="shock")

def arrow_flight(c, src, dst, t, t0, dur=0.28, glow=False):
    if t0 <= t < t0 + dur:
        p = (t - t0) / dur; x1 = src[0] + (dst[0] - src[0]) * p; y1 = src[1] + (dst[1] - src[1]) * p
        x0 = x1 - (dst[0] - src[0]) * 0.18; y0 = y1 - (dst[1] - src[1]) * 0.18
        P.arrow(c, x0, y0, x1, y1, glow=glow)
    if t0 + dur <= t < t0 + dur + 0.35:
        P.flash(c, dst[0], dst[1], 150, 1 - (t - t0 - dur) / 0.35)

def s_cut(c, t, lt):
    h1 = WT("n09", 3); h2 = WT("n09", 7)
    ram_aim = ease((t - T["n09"]) / 0.3); lak_aim = ease((t - WT("n09", 5) + 0.3) / 0.3)
    info = battle(c, t, mood=0.9, dust=max(0, 0.5 - lt * 0.5), stones_t0=None, ram_aim=ram_aim, ram_pull=1.0 if t < h1 - 0.28 else 0.3,
                  lak_aim=lak_aim)
    tk = tataka_state(t)
    rb = info["ram"].get("bowhand", (RX + 150, 820)); lb = info["lak"].get("bowhand", (LX + 150, 820))
    arrow_flight(c, rb, (tk["x"] - 170, 640), t, h1 - 0.28)
    arrow_flight(c, rb, (tk["x"] + 170, 640), t, h1 - 0.2)
    arrow_flight(c, lb, (tk["x"], TF - TH + 140), t, h2 - 0.28)

def smoke(c, x, y, t, a):
    if a <= 0: return
    rnd = random.Random(4)
    for k in range(14):
        ang = rnd.uniform(0, 6.3); r = rnd.uniform(40, 260) * (0.6 + a)
        cx_ = x + math.cos(ang + t * 0.8) * r; cy_ = y + math.sin(ang + t * 0.8) * r * 0.9
        c.arc(cx_, cy_, rnd.uniform(60, 140), 0, 6.3); c.set_source_rgba(0.35, 0.15, 0.4, 0.22 * a); c.fill()

def s_maya(c, t, lt):
    battle(c, t, mood=0.9, stones_t0=T["n10"] + 0.6, emo_r="worry", emo_l="worry")
    st = tataka_state(t)
    smoke(c, TX, 760, t, (1 - st["alpha"]) * (1 if st["alpha"] > 0.01 else max(0, 1 - (t - T["n10"] - 1.3) / 1.0)) + 0.3 * (1 - st["alpha"]))

def s_vm_angry(c, t, lt):
    dusk = ease((t - WT("v11", 3)) / 1.2)
    battle(c, t, mood=0.6, dusk=dusk, stones_t0=T["v11"] - 1, vm_emo="angry", vm_mouth=mouth("v11", t), vm_arms=(0.12, 0.05, 1.6, -0.5),
           emo_r="firm", emo_l="worry")
    c.set_source_rgba(0.8, 0.1, 0.05, 0.12 * ease(lt / 0.5)); c.paint()   # raudra light

def s_shabd(c, t, lt):
    hit = WT("n12", 15)
    shots = [WT("n12", 4) - 0.1, WT("n12", 5) + 0.05]
    aim = 1.0; pull = 1.0
    for s0 in shots + [hit - 0.3]:
        if s0 <= t < s0 + 0.2: pull = 0.2
    info = battle(c, t, mood=0.5, dusk=1.0, stones_t0=T["n12"] - 0.5 if t < WT("n12", 10) else None, ram_aim=aim, ram_pull=pull,
                  emo_r="firm", emo_l="firm", ram_look=0.9)
    rb = info["ram"].get("bowhand", (RX + 150, 820))
    for k, s0 in enumerate(shots):
        arrow_flight(c, rb, (650 + k * 150, 360 + k * 60), t, s0, 0.3)
    st = tataka_state(t)
    arrow_flight(c, rb, (st["x"], TF - TH * 0.6), t, hit - 0.3, 0.3, glow=True)
    # sound-wave icon near Ram's ear
    if WT("n12", 2) - 0.1 < t < WT("n12", 6):
        hx, hy = RX, 1200 - HS + 0.5 * HS / 5
        for k in range(3):
            r = 30 + k * 22 + (t * 60) % 22
            c.arc(hx + 50, hy, r, -0.7, 0.7); c.set_source_rgba(1, 0.95, 0.6, 0.85 - k * 0.25); c.set_line_width(5); c.stroke()

def s_fall(c, t, lt):
    battle(c, t, mood=0.4, dusk=1.0, emo_r="firm", emo_l="firm")
    fall = T["n13"] + 1.1
    if t > fall - 0.1:
        B.dust(c, t, max(0, 0.6 - (t - fall) * 0.5), cx=TX + 250, cy=1150)

def s_devta(c, t, lt):
    B.forest(c, t, mood=0.0, dusk=0.7, bloom=0.0)
    B.rays(c, 500, -80, ease(lt / 0.6), t)
    person(c, "vishwamitra2", VX + 360, 1200, HS, emo="joy", look=-0.6, arms=(-0.5, -1.6, 0.5, 1.6), blink=blink(t, 2.2))
    P.prince(c, "lakshman", LX + 40, 1200, HS, emo="joy", look=0.4, side=1, blink=blink(t, 0.4))
    P.prince(c, "ram", RX + 40, 1200, HS, emo="smile", look=0.3, side=1, blink=blink(t, 1.1))
    for k, w in enumerate(("साधु!", "साधु!")):
        t0 = WT("g14", k)
        if t > t0 - 0.05:
            a = ease((t - t0 + 0.05) / 0.25)
            overlay(lambda c, w=w, k=k, a=a: kc.paint_center(c, kc.text_img(w, 100, (255, 222, 90), stroke=3), 300 + k * 400, 260 + k * 70, a, 0.8 + 0.2 * a))

def s_bless(c, t, lt):
    bl = ease(lt / 1.6)
    B.forest(c, t, mood=0.0, dusk=0.4 * (1 - bl), bloom=bl)
    # Vishwamitra blesses Ram: hand on his head (Ram bows a little)
    P.prince(c, "lakshman", 170, 1200, HS, emo="joy", look=0.6, side=1, blink=blink(t, 0.4))
    P.prince(c, "ram", 430, 1200, HS, emo="smile", look=0.7, side=1, bow=0.5 * ease(lt / 0.6), blink=blink(t, 1.1))
    person(c, "vishwamitra2", 640, 1200, HS, emo="joy", look=-0.8, arms=(-1.75, -0.55, -0.12, -0.05), blink=blink(t, 2.2))
    q = WT("n15", 5)
    if t > q - 0.1:
        a = ease((t - q + 0.1) / 0.35)
        overlay(lambda c: astra_inset(c, t, a, WT("n15", 7)))

def astra_inset(c, t, a, tq):
    cx, cy, r = 500, 400, 230
    c.save(); c.push_group()
    c.arc(cx, cy, r, 0, 6.3); c.clip()
    B.sky(c, hexc("#3a1a5a"), hexc("#f2a23a"), 1220)
    B.rays(c, cx, cy, 1.0, t, n=18)
    # glowing divine weapons (silhouettes): chakra, arrow, trident-like spear
    c.save(); c.translate(cx - 110, cy); c.rotate(t * 2)
    for k in range(12):
        ang = k * math.pi / 6
        poly(c, [(math.cos(ang) * 40, math.sin(ang) * 40), (math.cos(ang + 0.2) * 80, math.sin(ang + 0.2) * 80), (math.cos(ang + 0.35) * 40, math.sin(ang + 0.35) * 40)])
        fill_stroke(c, "#f7c53f", 3)
    c.arc(0, 0, 42, 0, 6.3); fill_stroke(c, "#f2a23a", 4); c.restore()
    P.arrow(c, cx + 20, cy + 150, cx + 150, cy - 150, col="#f2c230", glow=True)
    if t > tq - 0.1:
        qa = ease((t - tq + 0.1) / 0.3)
        c.arc(cx, cy, r, 0, 6.3); c.set_source_rgba(0.1, 0.02, 0.05, 0.55 * qa); c.fill()
        kc.paint_center(c, kc.text_img("?", 300, (255, 222, 90), stroke=6), cx, cy - 10, qa, 0.7 + 0.3 * qa + 0.04 * math.sin(t * 8))
    c.reset_clip()
    c.arc(cx, cy, r, 0, 6.3); c.set_source_rgb(*hexc("#f2c230")); c.set_line_width(12); c.stroke()
    c.pop_group_to_source(); c.paint_with_alpha(a); c.restore()
    kc.paint_center(c, kc.text_img("दिव्य अस्त्र", 46, (255, 222, 90)), cx, cy + r + 50, a)

def s_end(c, t, lt):
    B.forest(c, t, mood=0.0, bloom=1.0)
    P.prince(c, "lakshman", 170, 1200, HS, emo="smile", look=0.6, side=1, blink=blink(t, 0.4))
    P.prince(c, "ram", 430, 1200, HS, emo="smile", look=0.0, side=1, blink=blink(t, 1.1))
    person(c, "vishwamitra2", 690, 1200, HS, emo="joy", look=-0.6, blink=blink(t, 2.2))
    a = ease(lt / 0.4); k = WT("n16", 8); b = ease((t - k + 0.1) / 0.3) if t > k - 0.1 else 0
    def ov(c):
        c.rectangle(60, 110, 880, 330); c.set_source_rgba(0.12, 0.03, 0.03, 0.8 * a); c.fill_preserve(); c.set_source_rgba(*hexc("#f2c230"), a); c.set_line_width(3); c.stroke()
        kc.paint_center(c, kc.text_img("अगले भाग में", 44, (255, 244, 220)), 500, 160, a)
        kc.paint_center(c, kc.text_img("विश्वामित्र के दिव्य अस्त्र", 58, (255, 222, 90), stroke=2), 500, 240, a)
        if b > 0: kc.paint_center(c, kc.text_img("कमेंट करें: जय श्री राम", 52, (255, 255, 255), stroke=2), 500, 360, b, 0.9 + 0.1 * b)
    overlay(ov)

# battle wide = cam (1.12, 500, 740); close on Ram head ~ (RX, 1200-HS+50)
RAMH = (RX, 1200 - HS + 60); TKH = (TX, TF - TH + 150); VMH = (660, 1200 - HS + 60)
SHOTS = [
    (0.0, "", s_hook, [(0, 1.9, RAMH[0] + 60, RAMH[1] + 90), (2.5, 1.55, 470, 650)]),
    (T["n02"] - 0.1, "गंगा पार", s_ganga, [(0, 1.15, 520, 780), (2.2, 1.25, 560, 800)]),
    (WT("n02", 5) - 0.15, "उजड़ा वन", s_enter, [(0, 1.12, 500, 740), (2.5, 1.15, 460, 700)]),
    (T["v03"] - 0.1, "ताड़का वन", s_vm_tells, [(0, 1.2, 520, 760), (0.6, 1.75, 640, 880), (2.0, 1.6, 600, 800), (4.0, 1.2, 520, 700)]),
    (T["n04"] - 0.1, "अगस्त्य का शाप", s_curse, [(0, 1.12, 500, 740), (6.0, 1.08, 500, 590)]),
    (T["n05"] - 0.1, "टंकार", s_twang, [(0, 1.8, RAMH[0] + 80, RAMH[1] + 120), (2.2, 1.7, RAMH[0] + 80, RAMH[1] + 120), (2.6, 1.12, 500, 740), (4.5, 1.2, 500, 730)]),
    (T["n06"] - 0.15, "ताड़का!", s_reveal, [(0, 1.12, 500, 740), (1.0, 1.15, 640, 560), (2.4, 1.25, 680, 520)]),
    (T["r07"] - 0.1, "राम का धर्म", s_ram_speaks, [(0, 1.12, 500, 740), (0.5, 1.6, 300, 900), (4.0, 1.65, 300, 900)]),
    (T["n08"] - 0.1, "धूल और पत्थर", s_dust, [(0, 1.2, 500, 730), (3.6, 1.15, 500, 640)]),
    (T["n09"] - 0.1, "बाणों की वर्षा", s_cut, [(0, 1.12, 500, 740), (3.5, 1.1, 560, 600)]),
    (T["n10"] - 0.1, "माया", s_maya, [(0, 1.1, 600, 600), (2.0, 1.12, 500, 740)]),
    (T["v11"] - 0.1, "संध्या से पहले", s_vm_angry, [(0, 1.12, 500, 740), (0.5, 2.0, VX + 20, VF - HS + 120), (3.5, 2.05, VX + 20, VF - HS + 120)]),
    (T["n12"] - 0.1, "शब्दभेदी बाण", s_shabd, [(0, 1.9, RAMH[0] + 60, RAMH[1] + 110), (2.3, 1.8, RAMH[0] + 60, RAMH[1] + 110), (2.9, 1.12, 500, 740), (6.5, 1.2, 520, 730)]),
    (T["n13"] - 0.1, "ताड़का वध", s_fall, [(0, 1.1, 620, 640), (2.0, 1.12, 500, 740)]),
    (T["g14"] - 0.4, "देव प्रसन्न", s_devta, [(0, 1.12, 500, 740), (2.4, 1.1, 460, 640)]),
    (T["n15"] - 0.1, "आशीर्वाद", s_bless, [(0, 1.15, 450, 760), (1.6, 1.12, 500, 740)]),
    (T["n16"] - 0.1, "अगला भाग", s_end, [(0, 1.12, 500, 740)]),
]
CUTS = [s[0] for s in SHOTS[1:]]

def shot_at(t):
    i = 0
    for k, s in enumerate(SHOTS):
        if t >= s[0]: i = k
    return i

def current_line(t):
    for lid, _ in SEQ:
        if T[lid] - 0.05 <= t < T[lid] + LINES[lid]["len"] + 0.25: return lid
    return None

FRAME = None
def frame_at(fi):
    global FRAME
    if FRAME is None: FRAME = kc.static_frame(TITLE, QUESTION)
    t = fi / FPS
    if fi < 3: return COVER()
    OVER.clear()
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    c.set_source_surface(FRAME, 0, 0); c.paint()
    i = shot_at(t); st, chipt, fn, keys = SHOTS[i]; lt = t - st
    c.save(); c.translate(SX, SY); c.rectangle(0, 0, SW, SH); c.clip()
    z, cx, cy = cam_at(keys, lt)
    # small shake on big hits
    sh = 0
    for ht, amp in ((WT("n05", 6), 14), (WT("n06", 2), 10), (T["n13"] + 1.1, 16), (WT("n12", 15), 8)):
        if ht <= t < ht + 0.5: sh = amp * (1 - (t - ht) / 0.5)
    cx += math.sin(t * 60) * sh; cy += math.cos(t * 53) * sh
    cx = min(max(cx, SW / 2 / z), SW - SW / 2 / z); cy = min(max(cy, SH / 2 / z), SH - SH / 2 / z)
    c.translate(SW / 2, SH / 2); c.scale(z, z); c.translate(-cx, -cy)
    fn(c, t, lt)
    c.restore()
    c.save(); c.translate(SX, SY); c.rectangle(0, 0, SW, SH); c.clip()
    for f in OVER: f(c)
    c.restore()
    # cut flash
    for ct in CUTS:
        if ct <= t < ct + 0.12:
            c.rectangle(SX, SY, SW, SH); c.set_source_rgba(1, 0.97, 0.85, 0.35 * (1 - (t - ct) / 0.12)); c.fill()
    if TOTAL - t < 0.35:
        c.rectangle(SX, SY, SW, SH); c.set_source_rgba(0.05, 0.01, 0.01, 1 - (TOTAL - t) / 0.35); c.fill()
    c.set_source_rgb(*hexc("#f2c230")); c.set_line_width(8); c.rectangle(SX - 4, SY - 4, SW + 8, SH + 8); c.stroke()
    kc.chip(c, chipt, ease(lt / 0.25))
    kc.draw_logo(c, W - 175, SY + 18, 120, 0.95)
    lid = current_line(t)
    if lid:
        L = LINES[lid]; lt2 = t - T[lid]
        al = min(1, (lt2 + 0.05) / 0.12, (L["len"] + 0.25 - lt2) / 0.15)
        kc.subtitle(c, L, lt2, NAMES, KEYS, max(0, al))
    # subscribe widget during the last line
    ws = T["n16"] + 0.2
    kc.subscribe_widget(c, t - ws, END_SPEECH - ws + 0.15, END_SPEECH - ws + 0.95)
    return s

# ---------------- cover ----------------
_COV = None
def COVER():
    global _COV
    if _COV is not None: return _COV
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    c.set_source_surface(kc.static_frame(TITLE, QUESTION), 0, 0); c.paint()
    c.save(); c.translate(SX, SY); c.rectangle(0, 0, SW, SH); c.clip()
    c.translate(SW / 2, SH / 2); c.scale(1.12, 1.12); c.translate(-500, -660)
    B.forest(c, 1.0, mood=1.0)
    P.tataka(c, TX, TF, TH, t=0.3, arms_up=1.0, mouth=1.0)
    P.prince(c, "lakshman", LX, 1200, HS, emo="firm", look=0.9, side=1)
    P.prince(c, "ram", RX, 1200, HS, emo="firm", look=0.9, aim=1.0, pull=1.0, side=1)
    c.restore()
    c.rectangle(SX, SY, SW, SH); c.set_source_rgba(0, 0, 0, 0); c.fill()
    # big glowing question mark
    g = cairo.RadialGradient(W / 2, 560, 0, W / 2, 560, 260); g.add_color_stop_rgba(0, 1, 0.85, 0.3, 0.55); g.add_color_stop_rgba(1, 1, 0.8, 0.2, 0)
    c.set_source(g); c.arc(W / 2, 560, 260, 0, 6.3); c.fill()
    kc.paint_center(c, kc.text_img("?", 330, (255, 222, 90), stroke=8), W / 2, 540)
    # hook band
    c.rectangle(60, 1300, W - 120, 150); c.set_source_rgba(0.1, 0.02, 0.03, 0.88); c.fill_preserve(); c.set_source_rgb(*hexc("#f2c230")); c.set_line_width(4); c.stroke()
    kc.paint_center(c, kc.text_img("स्त्री पर बाण?", 74, (255, 236, 120), stroke=2), W / 2, 1340)
    kc.paint_center(c, kc.text_img("ताड़का वध · वाल्मीकि रामायण", 40, (255, 244, 220), shadow=None), W / 2, 1415)
    c.set_source_rgb(*hexc("#f2c230")); c.set_line_width(8); c.rectangle(SX - 4, SY - 4, SW + 8, SH + 8); c.stroke()
    kc.draw_logo(c, W - 175, SY + 18, 120)
    kc.paint_center(c, kc.text_img("रामायण भाग 4", 64, (255, 222, 90), stroke=2), W / 2, PY + 120)
    kc.paint_center(c, kc.text_img("Katha Chitra", 40, (255, 244, 220), shadow=None), W / 2, PY + 210)
    _COV = s; return s

# ---------------- audio ----------------
def build_audio(path):
    n = int((TOTAL + 0.5) * kc.SR); mix = np.zeros(n, np.float32)
    def add(x, at, g=1.0):
        i = int(at * kc.SR); j = min(n, i + len(x)); mix[i:j] += x[: j - i] * g
    for lid, _ in SEQ:
        p = f"{D}/vo/{lid}.mp3"
        if os.path.exists(p):
            a = kc.load_audio(p)
            a = a[: int((LINES[lid]["len"] + 0.15) * kc.SR)]
            if LINES[lid]["spk"] == "G":   # divine echo
                e = np.zeros(len(a) + int(0.5 * kc.SR), np.float32); e[: len(a)] += a
                for d, g in ((0.18, 0.45), (0.36, 0.25)): i = int(d * kc.SR); e[i:i + len(a)] += a * g
                a = e
            add(a, T[lid], 1.0)
    bed = kc.music_bed(TOTAL); add(bed, 0, 1.0)
    for ct in CUTS: add(kc.sfx("whoosh", seed=int(ct * 10)), ct - 0.2, 0.35)
    add(kc.sfx("drum"), 0.1, 0.6)
    add(kc.sfx("twang"), WT("n05", 6) - 0.05, 0.75); add(kc.sfx("rumble"), WT("n05", 6), 0.6)
    add(kc.sfx("roar", seed=1), WT("n06", 0), 0.55); add(kc.sfx("drum", seed=2), WT("n06", 2), 0.8)
    add(kc.sfx("roar", seed=3), T["r07"] + 3.0, 0.25)
    add(kc.sfx("rumble", seed=4), T["n08"] + 0.6, 0.5)
    rnd = random.Random(1)
    for k in range(7): add(kc.sfx("thud", seed=k), WT("n08", 6) + k * 0.33 + rnd.uniform(0, 0.1), 0.35)
    for at in (WT("n09", 3) - 0.28, WT("n09", 3) - 0.2, WT("n09", 7) - 0.28): add(kc.sfx("arrow", seed=int(at * 7)), at, 0.6)
    for at in (WT("n09", 3), WT("n09", 7)): add(kc.sfx("impact", seed=int(at)), at, 0.55); add(kc.sfx("roar", seed=int(at * 3)), at + 0.05, 0.3)
    for k in range(4): add(kc.sfx("thud", seed=10 + k), T["n10"] + 0.8 + k * 0.45, 0.25)
    add(kc.sfx("drum", seed=5), T["v11"] + 0.05, 0.5)
    for at in (WT("n12", 4) - 0.1, WT("n12", 5) + 0.05, WT("n12", 15) - 0.3): add(kc.sfx("arrow", seed=int(at * 5)), at, 0.6)
    add(kc.sfx("roar", seed=6), WT("n12", 10), 0.45); add(kc.sfx("impact", seed=7), WT("n12", 15), 0.8)
    add(kc.sfx("thud", seed=20), T["n13"] + 1.1, 1.0); add(kc.sfx("rumble", seed=21), T["n13"] + 1.1, 0.6)
    add(kc.sfx("sparkle"), T["g14"] - 0.3, 0.45); add(kc.sfx("sparkle", seed=2), WT("n15", 5), 0.35)
    ws = T["n16"] + 0.2
    add(kc.sfx("click"), END_SPEECH + 0.15, 0.8); add(kc.sfx("ting"), END_SPEECH + 0.95, 0.8)
    kc.write_wav(path, mix)

# ---------------- render ----------------
def render_part(a, b, out):
    tmp = out + ".part.mp4"
    ff = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgra", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                           "-c:v", "libx264", "-preset", "veryfast", "-crf", "21", "-pix_fmt", "yuv420p", tmp], stdin=subprocess.PIPE)
    for fi in range(a, b): ff.stdin.write(bytes(frame_at(fi).get_data()))
    ff.stdin.close(); ff.wait()
    if ff.returncode == 0: os.replace(tmp, out)

if __name__ == "__main__":
    print("total", round(TOTAL, 2), "frames", NF)
    cmd = sys.argv[1] if len(sys.argv) > 1 else "all"
    if cmd == "stills":
        ts = [float(x) for x in sys.argv[2:]]
        from PIL import Image
        ims = []
        for tt in ts:
            s = frame_at(int(tt * FPS)); s.write_to_png("/tmp/st.png"); ims.append(Image.open("/tmp/st.png").convert("RGB").resize((270, 480)))
        cols = 6; rows = (len(ims) + cols - 1) // cols
        sheet = Image.new("RGB", (cols * 270, rows * 480))
        for k, im in enumerate(ims): sheet.paste(im, ((k % cols) * 270, (k // cols) * 480))
        sheet.save(f"{D}/sheet.jpg", quality=85)
    elif cmd == "part":
        a, b, out = int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]; render_part(a, b, out)
    elif cmd == "audio":
        build_audio(f"{D}/mix.wav")
    elif cmd == "cover":
        COVER().write_to_png(f"{D}/cover.png")
