"""Backgrounds for Bhag 4 (scene coords 1000 x 1220)."""
import math, random, cairo
from chars import hexc, fill_stroke, ellipse, poly, OL
import scenes as S

SW, SH = 1000, 1220

def mix(a, b, p):
    a, b = hexc(a), hexc(b); return tuple(a[i] + (b[i] - a[i]) * p for i in range(3))

def sky(c, top, bot, y1=760):
    g = cairo.LinearGradient(0, 0, 0, y1); g.add_color_stop_rgb(0, *top); g.add_color_stop_rgb(1, *bot)
    c.set_source(g); c.rectangle(0, 0, SW, y1 + 5); c.fill()

def dead_tree(c, x, y, s, col="#3a2a24", sway=0.0):
    """twisted bare tree, folk-art style"""
    c.save(); c.translate(x, y); c.rotate(sway * 0.02)
    poly(c, [(-0.14 * s, 0), (0.14 * s, 0), (0.07 * s, -1.0 * s), (-0.07 * s, -1.0 * s)]); fill_stroke(c, col, 4)
    rnd = random.Random(int(x * 7 + y))
    def br(x0, y0, a, ln, w, d):
        x1, y1 = x0 + math.sin(a) * ln, y0 - math.cos(a) * ln
        c.move_to(x0, y0); c.curve_to(x0 + math.sin(a) * ln * 0.4 + 10, y0 - math.cos(a) * ln * 0.5, x1 - 8, y1 + 10, x1, y1)
        c.set_source_rgb(*OL); c.set_line_width(w + 7); c.set_line_cap(cairo.LINE_CAP_ROUND); c.stroke_preserve()
        c.set_source_rgb(*hexc(col)); c.set_line_width(w); c.stroke()
        if d > 0:
            for da in (-0.55, 0.5):
                br(x1, y1, a + da + rnd.uniform(-0.15, 0.15), ln * 0.65, w * 0.6, d - 1)
    br(0, -0.95 * s, -0.4, 0.55 * s, 0.11 * s, 2); br(0, -0.95 * s, 0.45, 0.6 * s, 0.11 * s, 2)
    c.restore()

def leafy_tree(c, x, y, s, col="#2f6b3a", bloom=0.0):
    S.tree(c, x, y, s, col)
    if bloom > 0:
        rnd = random.Random(int(x))
        for k in range(10):
            a = rnd.uniform(0, 6.3); r = rnd.uniform(0.1, 0.5) * s
            c.arc(x + math.cos(a) * r, y - 1.4 * s + math.sin(a) * r, 0.06 * s * bloom, 0, 6.3)
            fill_stroke(c, "#f27aa0" if k % 2 else "#f7c53f", 2)

def bush(c, x, y, s, col="#3a4a2a"):
    for dx, r in ((-0.5, 0.4), (0, 0.55), (0.5, 0.42)):
        c.arc(x + dx * s, y - r * s * 0.6, r * s, math.pi, 0); fill_stroke(c, col, 4)

def ground(c, y0, c0, c1, crack=True):
    c.rectangle(0, y0, SW, SH - y0); c.set_source(S.grad(c, y0, SH, c0, c1)); c.fill()
    c.move_to(0, y0); c.line_to(SW, y0); c.set_source_rgb(*OL); c.set_line_width(4); c.stroke()
    if crack:
        rnd = random.Random(3); c.set_source_rgba(*OL, 0.35); c.set_line_width(2.5)
        for k in range(14):
            x = rnd.uniform(0, SW); y = rnd.uniform(y0 + 40, SH - 20)
            c.move_to(x, y); c.line_to(x + 30, y + 8); c.line_to(x + 45, y - 4); c.stroke()

def swirl_cloud(c, x, y, s, col):
    S.swirl_cloud(c, x, y, s, col)

def folk_moon_sun(c, x, y, r, col="#f7c53f", dim=0.0):
    c.arc(x, y, r * 1.6, 0, 6.3); c.set_source_rgba(1, 0.8, 0.3, 0.25 * (1 - dim)); c.fill()
    S.folk_sun(c, x, y, r)

# ---- dreadful forest: dim, dead trees, grey-green sky ----
def forest(c, t, mood=0.0, dusk=0.0, bloom=0.0, shake=0.0):
    """mood: 0 eerie, 1 fear red-black. dusk: 0..1 sunset. bloom: 0..1 forest becomes beautiful."""
    top = mix("#4a5a5a", "#3a0c10", mood); bot = mix("#8a9478", "#7a2018", mood)
    top = tuple(top[i] + (hexc("#d9542a")[i] - top[i]) * dusk * 0.8 for i in range(3))
    bot = tuple(bot[i] + (hexc("#f2a23a")[i] - bot[i]) * dusk * 0.85 for i in range(3))
    if bloom > 0:
        top = tuple(top[i] + (hexc("#f08a5a")[i] - top[i]) * bloom for i in range(3))
        bot = tuple(bot[i] + (hexc("#fbd48a")[i] - bot[i]) * bloom for i in range(3))
    sky(c, top, bot, 760)
    if dusk > 0.05:
        sy = 640 + 120 * dusk
        c.arc(780, sy, 70, 0, 6.3); c.set_source_rgba(1, 0.75, 0.3, dusk); c.fill()
        c.arc(780, sy, 120, 0, 6.3); c.set_source_rgba(1, 0.6, 0.2, 0.25 * dusk); c.fill()
    for (x, y, s) in ((150, 140, 60), (620, 210, 50)):
        S.swirl_cloud(c, x + math.sin(t * 0.3) * 10, y, s, "#9aa69a" if bloom < 0.5 and dusk < 0.5 else "#fbe3b0")
    # far hills
    c.move_to(0, 700)
    for k in range(11):
        c.curve_to(k * 100 + 30, 600 + (k % 3) * 25, k * 100 + 70, 600 + (k % 2) * 30, k * 100 + 100, 690)
    c.line_to(SW, 760); c.line_to(0, 760); c.close_path()
    fill_stroke(c, mix("#4a5a48", "#2f7a3a", bloom) if mood < 0.5 else "#2a1012", 4)
    ground(c, 760, mix("#8a7a5a", "#7aa04a", bloom), mix("#5a4a32", "#4a7a32", bloom))
    sw_ = math.sin(t * 2) * (1 + shake * 8)
    for (x, y, s) in ((80, 800, 260), (330, 770, 200), (900, 810, 280), (640, 780, 190)):
        if bloom > 0.5:
            leafy_tree(c, x, y, s * 0.55, "#2f8a4a", bloom=bloom)
        else:
            dead_tree(c, x, y, s, "#3a2a24" if mood < 0.5 else "#1a0a0a", sway=sw_)
    for (x, y, s) in ((200, 1210, 80), (820, 1215, 90)):
        bush(c, x, y, s, mix("#3a4a2a", "#2f8a4a", bloom))
    if bloom > 0.3:
        rnd = random.Random(11)
        for k in range(30):
            x = rnd.uniform(20, SW - 20); y = rnd.uniform(790, 1200)
            c.arc(x, y, 7 * bloom, 0, 6.3); fill_stroke(c, "#f27aa0" if k % 3 == 0 else ("#f7c53f" if k % 3 == 1 else "#ffffff"), 2)
    # fog strip
    c.set_source_rgba(0.85, 0.85, 0.8, 0.18 * (1 - bloom)); c.rectangle(0, 720 + math.sin(t) * 6, SW, 70); c.fill()

# ---- Ganga crossing ----
def ganga(c, t):
    sky(c, hexc("#f5c873"), hexc("#fbe3a8"), 640)
    S.folk_sun(c, 820, 200, 60, t)
    S.swirl_cloud(c, 230, 160, 55, "#fbe3b0")
    # far bank (south): dark forest line
    c.move_to(0, 600)
    for k in range(20):
        c.line_to(k * 52 + 26, 540 - (k % 3) * 18); c.line_to(k * 52 + 52, 600)
    c.line_to(SW, 640); c.line_to(0, 640); c.close_path(); fill_stroke(c, "#3a4a3a", 4)
    c.rectangle(0, 640, SW, SH - 640); c.set_source(S.grad(c, 640, SH, "#5ab0e0", "#2a6aa8")); c.fill()
    c.set_source_rgb(*OL); c.set_line_width(3)
    for row in range(12):
        y = 680 + row * 46; off = (t * 40 + row * 23) % 60
        for k in range(-1, 19):
            x = k * 60 + off - 30
            c.arc(x, y, 30, math.pi * 1.1, math.pi * 1.9); c.set_source_rgba(1, 1, 1, 0.55); c.set_line_width(3); c.stroke()

def boat_front(c, x, y, w, h=170):
    """hull drawn OVER seated people; y = waterline"""
    c.move_to(x - w / 2 - 70, y - h); c.curve_to(x - w / 2 - 20, y + 30, x + w / 2 + 20, y + 30, x + w / 2 + 80, y - h - 20)
    c.line_to(x + w / 2 + 30, y - h + 10); c.line_to(x - w / 2 - 30, y - h + 10); c.close_path(); fill_stroke(c, "#8a4a22", 5)
    c.move_to(x - w / 2 - 20, y - h + 45); c.line_to(x + w / 2 + 30, y - h + 45); c.set_source_rgb(*hexc("#f2c230")); c.set_line_width(10); c.stroke()
    for k in range(7):
        c.arc(x - w / 2 + 20 + k * (w - 20) / 6, y - h + 45, 9, 0, 6.3); fill_stroke(c, "#d9342b", 2)
    c.set_source_rgba(1, 1, 1, 0.6); c.set_line_width(4)
    for k in range(5):
        c.arc(x - w / 2 + k * w / 4, y + 12, 26, math.pi * 1.1, math.pi * 1.9); c.stroke()

def stones(c, t, t0, n=14, seed=5, area=(0, SW), ybot=1150):
    """stones raining from the sky"""
    rnd = random.Random(seed)
    for k in range(n):
        st = t0 + rnd.uniform(0, 1.2); x = rnd.uniform(*area); sz = rnd.uniform(18, 38)
        ph = ((t - st) % 1.4) / 1.4 if t > st else -1
        if ph < 0: continue
        y = -60 + ph * (ybot + 60) * 1.1
        if y > ybot:
            continue
        c.save(); c.translate(x + ph * 60, y); c.rotate(ph * 6)
        poly(c, [(-sz, -sz * 0.4), (-sz * 0.3, -sz), (sz * 0.8, -sz * 0.6), (sz, sz * 0.3), (0, sz * 0.9), (-sz * 0.8, sz * 0.5)])
        fill_stroke(c, "#7a7068", 3); c.restore()

def dust(c, t, amt, cx=500, cy=900):
    if amt <= 0: return
    rnd = random.Random(9)
    for k in range(26):
        a = rnd.uniform(0, 6.3) + t * rnd.uniform(0.8, 2.0)
        r = rnd.uniform(80, 520)
        x = cx + math.cos(a) * r; y = cy + math.sin(a) * r * 0.55
        rr = rnd.uniform(90, 200)
        c.arc(x, y, rr, 0, 6.3); c.set_source_rgba(0.62, 0.5, 0.35, 0.2 * amt); c.fill()
    c.set_source_rgba(0.55, 0.45, 0.3, 0.3 * amt); c.paint()
    c.set_source_rgba(*OL, 0.35 * amt); c.set_line_width(4)
    for k in range(6):
        r = 120 + k * 70 + (t * 120) % 70
        c.arc(cx, cy, r, 0.3 + t + k, 1.5 + t + k); c.stroke()

def rays(c, x, y, a, t, n=14):
    if a <= 0: return
    c.save(); c.translate(x, y)
    for k in range(n):
        ang = math.pi * 0.15 + k * math.pi * 0.7 / (n - 1) + math.sin(t + k) * 0.02
        g = cairo.LinearGradient(0, 0, math.cos(ang) * 1400, math.sin(ang) * 1400)
        g.add_color_stop_rgba(0, 1, 0.9, 0.5, 0.55 * a); g.add_color_stop_rgba(1, 1, 0.85, 0.4, 0)
        c.set_source(g)
        poly(c, [(0, 0), (math.cos(ang - 0.04) * 1400, math.sin(ang - 0.04) * 1400), (math.cos(ang + 0.04) * 1400, math.sin(ang + 0.04) * 1400)]); c.fill()
    c.restore()

def birds(c, t, t0, n=7):
    if t < t0: return
    p = t - t0; rnd = random.Random(2)
    c.set_source_rgb(*OL); c.set_line_width(4)
    for k in range(n):
        x = rnd.uniform(100, 900) + p * rnd.uniform(150, 300) * (1 if k % 2 else -1)
        y = rnd.uniform(450, 700) - p * rnd.uniform(200, 320)
        f = math.sin(p * 18 + k) * 10
        c.move_to(x - 22, y - f); c.line_to(x, y); c.line_to(x + 22, y - f); c.stroke()
