"""Katha Chitra Ramayan video template: frame, title, question banner, logo, chips, word-by-word subtitles,
subscribe widget, lip-sync, sound effects, audio mixing and parallel rendering.
An episode file only supplies: TITLE, QUESTION, line sequence, shots, key words, cover drawing."""
import math, os, json, wave, subprocess, hashlib
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont
from chars import hexc, fill_stroke, ellipse, poly, OL

W, H, FPS = 1080, 1920, 30
SX, SY, SW, SH = 40, 240, 1000, 1220
PY = SY + SH + 26
FONT = "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf"
FONT_M = "/usr/share/fonts/truetype/google-fonts/Poppins-SemiBold.ttf"
if not os.path.exists(FONT_M): FONT_M = FONT
HERE = os.path.dirname(os.path.abspath(__file__))
SR = 24000

def ease(x):
    x = max(0.0, min(1.0, x)); return x * x * (3 - 2 * x)

def blink(t, off=0.0):
    return (t + off) % 3.7 < 0.11

# ---------------- text ----------------
_TC = {}
def text_img(txt, size, col, font=FONT, shadow=(30, 6, 4), stroke=0):
    key = (txt, size, col, font, shadow, stroke)
    if key in _TC: return _TC[key]
    f = ImageFont.truetype(font, size, layout_engine=ImageFont.Layout.RAQM)
    d = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    bb = d.textbbox((0, 0), txt, font=f, stroke_width=stroke)
    w, h = bb[2] - bb[0] + 16, int(size * 1.55) + 10
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0)); dr = ImageDraw.Draw(im)
    if shadow: dr.text((8 - bb[0] + 3, 6 + 3), txt, font=f, fill=shadow, stroke_width=stroke, stroke_fill=shadow)
    dr.text((8 - bb[0], 6), txt, font=f, fill=col, stroke_width=stroke, stroke_fill=(40, 8, 4))
    p = f"/tmp/kc_{hashlib.md5(repr(key).encode()).hexdigest()}.png"; im.save(p)
    s = cairo.ImageSurface.create_from_png(p); _TC[key] = s; return s

def paint_center(c, surf, x, y, alpha=1.0, scale=1.0):
    c.save(); c.translate(x, y); c.scale(scale, scale)
    c.set_source_surface(surf, -surf.get_width() / 2, -surf.get_height() / 2); c.paint_with_alpha(alpha); c.restore()

# ---------------- static frame ----------------
def static_frame(title, question):
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    c.set_source_rgb(*hexc("#7a1424")); c.paint()
    c.set_source_rgb(*hexc("#f2c230")); c.set_line_width(4); c.rectangle(10, 10, W - 20, H - 20); c.stroke()
    for k in range(0, H, 40):
        for x in (22, W - 22):
            poly(c, [(x, k), (x + 9, k + 20), (x, k + 40), (x - 9, k + 20)]); fill_stroke(c, "#f2c230", 2)
    for k in range(0, W, 40):
        for y in (22, H - 22):
            poly(c, [(k, y), (k + 20, y - 9), (k + 40, y), (k + 20, y + 9)]); fill_stroke(c, "#f2c230", 2)
    # title cartouche with corner rosettes
    c.rectangle(60, 44, W - 120, 182); c.set_source_rgb(*hexc("#5a0c18")); c.fill_preserve(); c.set_source_rgb(*hexc("#f2c230")); c.set_line_width(5); c.stroke()
    c.rectangle(72, 56, W - 144, 158); c.set_line_width(2); c.stroke()
    for (x, y) in ((72, 56), (W - 72, 56), (72, 214), (W - 72, 214)):
        for k in range(8):
            a = k * math.pi / 4
            c.arc(x + math.cos(a) * 11, y + math.sin(a) * 11, 6, 0, 6.3); fill_stroke(c, "#f2a23a", 1.5)
        c.arc(x, y, 7, 0, 6.3); fill_stroke(c, "#d9342b", 1.5)
    paint_center(c, text_img(title, 36, (255, 214, 90)), W / 2, 92)
    paint_center(c, text_img(question, 50, (255, 236, 120), stroke=2), W / 2, 168)
    # dialogue panel
    c.rectangle(50, PY, W - 100, H - 70 - PY); c.set_source_rgb(*hexc("#3a0a10")); c.fill_preserve(); c.set_source_rgb(*hexc("#f2c230")); c.set_line_width(5); c.stroke()
    c.rectangle(64, PY + 14, W - 128, H - 70 - PY - 28); c.set_line_width(2); c.stroke()
    return s

_LOGO = None
def logo_surface():
    global _LOGO
    if _LOGO is None:
        Image.open(os.path.join(HERE, "katha_chitra_logo.png")).convert("RGBA").save("/tmp/kc_logo.png")
        _LOGO = cairo.ImageSurface.create_from_png("/tmp/kc_logo.png")
    return _LOGO

def draw_logo(c, x, y, size, alpha=1.0):
    L = logo_surface(); k = size / 200.0
    c.save(); c.translate(x, y); c.scale(k, k); c.arc(100, 100, 98, 0, 6.3); c.clip(); c.set_source_surface(L, 0, 0); c.paint_with_alpha(alpha); c.restore()
    c.arc(x + size / 2, y + size / 2, size / 2, 0, 6.3); c.set_source_rgba(*hexc("#f2c230"), alpha); c.set_line_width(3); c.stroke()

def chip(c, text, a):
    if a <= 0 or not text: return
    s = text_img(text, 34, (255, 244, 220), shadow=None)
    w = s.get_width() + 30; x, y = SX + 22, SY + 20
    c.save(); c.translate(x, y)
    c.move_to(14, 0); c.line_to(w, 0); c.line_to(w - 14, 58); c.line_to(0, 58); c.close_path()
    c.set_source_rgba(*hexc("#8e1b2b"), 0.92 * a); c.fill_preserve(); c.set_source_rgba(*hexc("#f2c230"), a); c.set_line_width(3); c.stroke()
    c.set_source_surface(s, 15, -1); c.paint_with_alpha(a); c.restore()

# ---------------- word-by-word subtitles ----------------
def subtitle(c, line, lt, names, keys, alpha=1.0):
    """line: dict with words [[st,dur,w]...]; lt: time since line start."""
    top = PY + 30
    nm = names.get(line["spk"])
    if nm:
        paint_center(c, text_img(nm, 38, (240, 190, 60), shadow=None), W / 2, top + 22, alpha); top += 56
    else:
        top += 14
    size = 52; gap = 16; maxw = 900
    items = []
    for k, (st, du, w) in enumerate(line["words"]):
        key = any(kk in w for kk in keys)
        items.append((st, du, w, key))
    # layout
    surfs = [text_img(w, size, (255, 244, 220), shadow=(20, 4, 2)) for _, _, w, _ in items]
    rows, cur, cw = [], [], 0
    for i, s in enumerate(surfs):
        ww = s.get_width() - 16
        if cur and cw + gap + ww > maxw: rows.append((cur, cw)); cur, cw = [], 0
        cur.append(i); cw += (gap if cw else 0) + ww
    rows.append((cur, cw))
    y = top + 38
    for idxs, rw in rows:
        x = W / 2 - rw / 2
        for i in idxs:
            st, du, w, key = items[i]
            s = surfs[i]; ww = s.get_width() - 16
            spoken = lt >= st - 0.03; current = st - 0.03 <= lt < st + du + 0.05
            col = (255, 214, 60) if (key and spoken) else (255, 244, 220)
            ss = text_img(w, size, col, shadow=(20, 4, 2))
            a = (1.0 if spoken else 0.32) * alpha
            sc = 1.08 if current else 1.0
            paint_center(c, ss, x + ww / 2, y, a, sc)
            x += ww + gap
        y += int(size * 1.5)

# ---------------- subscribe widget ----------------
def subscribe_widget(c, lt, t_click, t_bell):
    """lt: time since widget start. small modern pill sliding in at the bottom of the scene area."""
    if lt < 0: return
    a = ease(lt / 0.45); wx, wy, ww, wh = W / 2 - 360, SY + SH - 150 + (1 - a) * 160, 720, 116
    c.save()
    c.rectangle(SX, SY, SW, SH); c.clip()
    c.new_path()
    r = wh / 2
    c.arc(wx + r, wy + r, r, math.pi / 2, 3 * math.pi / 2); c.arc(wx + ww - r, wy + r, r, -math.pi / 2, math.pi / 2); c.close_path()
    c.set_source_rgba(0.08, 0.03, 0.03, 0.92); c.fill_preserve(); c.set_source_rgb(*hexc("#f2c230")); c.set_line_width(3); c.stroke()
    draw_logo(c, wx + 14, wy + 13, 90)
    paint_center(c, text_img("Katha Chitra", 32, (255, 244, 220), shadow=None), wx + 200, wy + 40)
    paint_center(c, text_img("@kathachitra_123", 22, (220, 200, 170), shadow=None, font=FONT_M), wx + 200, wy + 80)
    clicked = lt >= t_click
    bx, by, bw, bh = wx + 330, wy + 26, 230, 64
    press = 1 - 0.08 * max(0, 1 - abs(lt - t_click) / 0.12)
    c.save(); c.translate(bx + bw / 2, by + bh / 2); c.scale(press, press)
    c.rectangle(-bw / 2, -bh / 2, bw, bh); c.set_source_rgb(*((0.35, 0.35, 0.35) if clicked else hexc("#e8202a"))); c.fill()
    paint_center(c, text_img("✓ SUBSCRIBED" if clicked else "SUBSCRIBE", 26, (255, 255, 255), shadow=None), 0, 2)
    c.restore()
    # bell
    gx, gy = wx + 625, wy + 58
    ring = lt >= t_bell; sh = math.sin((lt - t_bell) * 40) * 0.35 * max(0, 1 - (lt - t_bell) / 0.9) if ring else 0
    if ring:
        g = cairo.RadialGradient(gx, gy, 0, gx, gy, 60); g.add_color_stop_rgba(0, 1, 0.85, 0.2, 0.7); g.add_color_stop_rgba(1, 1, 0.8, 0.1, 0)
        c.set_source(g); c.arc(gx, gy, 60, 0, 6.3); c.fill()
    c.save(); c.translate(gx, gy - 22); c.rotate(sh)
    c.move_to(-22, 32); c.curve_to(-22, -6, -16, -2, 0, -2); c.curve_to(16, -2, 22, -6, 22, 32); c.line_to(28, 40); c.line_to(-28, 40); c.close_path()
    fill_stroke(c, "#f2c230" if ring else "#e8e0d0", 3)
    c.arc(0, 46, 7, 0, 6.3); fill_stroke(c, "#f2c230" if ring else "#e8e0d0", 3)
    c.restore()
    # finger: moves to subscribe, presses, then to bell
    if lt > t_click - 0.6 and lt < t_bell + 0.6:
        if lt < t_click + 0.25:
            p = ease((lt - (t_click - 0.6)) / 0.5); fx, fy = bx + bw / 2 + 120 * (1 - p), by + bh / 2 + 120 * (1 - p)
            dn = max(0, 1 - abs(lt - t_click) / 0.1) * 10
        else:
            p = ease((lt - (t_click + 0.25)) / max(0.1, t_bell - t_click - 0.3)); fx = bx + bw / 2 + (gx - bx - bw / 2) * p; fy = by + bh / 2 + (gy - by - bh / 2) * p
            dn = max(0, 1 - abs(lt - t_bell) / 0.1) * 10
        hand(c, fx + 18, fy + 22 + dn, max(0.0, min(1.0, (t_bell + 0.6 - lt) / 0.3)))
    c.restore()

def hand(c, x, y, a):
    c.save(); c.translate(x, y); c.rotate(-0.35); c.push_group()
    c.move_to(-9, 0); c.line_to(-9, -42); c.curve_to(-9, -54, 9, -54, 9, -42); c.line_to(9, -6)
    c.curve_to(30, -14, 40, -4, 38, 18); c.curve_to(36, 44, 20, 58, -2, 58); c.curve_to(-22, 58, -30, 40, -30, 20); c.curve_to(-30, 6, -18, 2, -9, 0)
    c.close_path(); fill_stroke(c, "#ffffff", 3.5)
    c.pop_group_to_source(); c.paint_with_alpha(a); c.restore()

# ---------------- lip-sync ----------------
def mouth_track(a, sr=SR):
    win = int(sr * 0.045); n = int(len(a) / sr * FPS) + 1; feats = []
    for k in range(n):
        cc = int(k / FPS * sr); seg = a[max(0, cc - win // 2): cc + win // 2]
        if len(seg) < 64: feats.append((0, 0, 0)); continue
        rms = float(np.sqrt(np.mean(seg ** 2)))
        sp = np.abs(np.fft.rfft(seg * np.hanning(len(seg)))); fr = np.fft.rfftfreq(len(seg), 1 / sr)
        lo = sp[(fr > 200) & (fr < 900)].sum() + 1e-9
        feats.append((rms, sp[(fr > 900) & (fr < 2000)].sum() / lo, sp[(fr > 2000) & (fr < 4500)].sum() / lo))
    ref = np.percentile([f[0] for f in feats], 90) + 1e-9
    voiced = [f for f in feats if f[0] / ref >= 0.33] or feats
    m_lo = np.percentile([f[1] for f in voiced], 25); h_hi = np.percentile([f[2] for f in voiced], 80)
    rr = [f[0] / ref for f in feats]; out = []
    for k, (rms, m, h) in enumerate(feats):
        r = rr[k]
        if r < 0.13: s = "X"
        elif 0 < k < len(rr) - 1 and r < 0.55 and rr[k - 1] > r and rr[k + 1] > r: s = "M"
        elif r < 0.33: s = "A"
        elif h >= h_hi: s = "E"
        elif m <= m_lo: s = "O"
        elif r > 0.75: s = "B"
        else: s = "A"
        out.append(s)
    for k in range(1, len(out) - 1):
        if out[k - 1] == out[k + 1] != out[k]: out[k] = out[k - 1]
    return out

def mouth_from_words(words, lt):
    for st, du, w in words:
        if st <= lt < st + du:
            ph = (lt - st) / max(du, 0.05)
            return "BAOEA"[int(ph * 5) % 5]
    return "X"

# ---------------- audio ----------------
def load_audio(path):
    r = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-f", "s16le", "-ac", "1", "-ar", str(SR), "-"], capture_output=True, check=True)
    return np.frombuffer(r.stdout, np.int16).astype(np.float32) / 32768

def sfx(kind, sr=SR, seed=0):
    rnd = np.random.default_rng(seed)
    if kind == "whoosh":
        n = int(0.45 * sr); k = np.arange(n) / sr; x = rnd.standard_normal(n)
        env = np.sin(np.pi * k / 0.45) ** 2
        out = np.zeros(n); lp = 0.0; cut = 0.02 + 0.25 * np.sin(np.pi * k / 0.45)
        for i in range(n): lp += cut[i] * (x[i] - lp); out[i] = lp
        return (out * env * 0.9).astype(np.float32)
    if kind == "drum":
        n = int(0.9 * sr); k = np.arange(n) / sr
        return (np.sin(2 * np.pi * (55 + 70 * np.exp(-k * 15)) * k) * np.exp(-k * 5) * 1.0 + rnd.standard_normal(n) * np.exp(-k * 40) * 0.25).astype(np.float32)
    if kind == "twang":
        n = int(1.6 * sr); p = int(sr / 98); buf = rnd.uniform(-1, 1, p); out = np.zeros(n)
        for i in range(n):
            out[i] = buf[i % p]; buf[i % p] = 0.5 * (buf[i % p] + buf[(i + 1) % p]) * 0.998
        k = np.arange(n) / sr
        boom = np.sin(2 * np.pi * (45 + 30 * np.exp(-k * 8)) * k) * np.exp(-k * 3)
        return ((out * 0.8 + boom * 0.6) * np.exp(-k * 1.2)).astype(np.float32)
    if kind == "roar":
        n = int(1.4 * sr); k = np.arange(n) / sr; x = rnd.standard_normal(n)
        f0 = 70 + 25 * np.sin(k * 9); ph = np.cumsum(2 * np.pi * f0 / sr)
        saw = (ph / np.pi) % 2 - 1
        lp = np.convolve(x, np.ones(30) / 30, mode="same")
        env = np.minimum(1, k / 0.15) * np.exp(-np.maximum(0, k - 0.8) * 4)
        return ((saw * 0.55 + lp * 2.5) * env * (0.7 + 0.3 * np.sin(k * 23))).astype(np.float32)
    if kind == "thud":
        n = int(0.5 * sr); k = np.arange(n) / sr
        return (np.sin(2 * np.pi * (70 + 40 * np.exp(-k * 25)) * k) * np.exp(-k * 12) * 0.8 + rnd.standard_normal(n) * np.exp(-k * 60) * 0.3).astype(np.float32)
    if kind == "arrow":
        n = int(0.35 * sr); k = np.arange(n) / sr; x = rnd.standard_normal(n)
        hp = x - np.convolve(x, np.ones(6) / 6, mode="same")
        return (hp * np.sin(np.pi * k / 0.35) ** 2 * 0.6).astype(np.float32)
    if kind == "impact":
        n = int(0.8 * sr); k = np.arange(n) / sr
        return (np.sin(2 * np.pi * (60 + 90 * np.exp(-k * 20)) * k) * np.exp(-k * 6) + rnd.standard_normal(n) * np.exp(-k * 25) * 0.6).astype(np.float32)
    if kind == "sparkle":
        n = int(1.4 * sr); k = np.arange(n) / sr; out = np.zeros(n)
        for j, f in enumerate((1568, 2093, 2637, 3136, 2349, 2794)):
            st = int(j * 0.11 * sr); kk = k[: n - st]
            out[st:] += np.sin(2 * np.pi * f * kk) * np.exp(-kk * 5) * 0.25
        return out.astype(np.float32)
    if kind == "click":
        n = int(0.08 * sr); k = np.arange(n) / sr
        return (rnd.standard_normal(n) * np.exp(-k * 120) * 0.6 + np.sin(2 * np.pi * 2200 * k) * np.exp(-k * 90) * 0.4).astype(np.float32)
    if kind == "ting":
        n = int(1.2 * sr); k = np.arange(n) / sr; out = np.zeros(n)
        for st in (0.0, 0.28):
            i = int(st * sr); kk = k[: n - i]
            out[i:] += (np.sin(2 * np.pi * 1760 * kk) + 0.5 * np.sin(2 * np.pi * 4400 * kk) + 0.3 * np.sin(2 * np.pi * 2640 * kk)) * np.exp(-kk * 4) * 0.35
        return out.astype(np.float32)
    if kind == "rumble":
        n = int(1.2 * sr); k = np.arange(n) / sr; x = np.convolve(rnd.standard_normal(n), np.ones(200) / 200, mode="same") * 12
        return (x * np.sin(np.pi * k / 1.2)).astype(np.float32)
    raise ValueError(kind)

def music_bed(total, sr=SR, dark=None):
    """tanpura-like drone + soft dhol pulse. dark: list of (t0,t1) where it goes lower/minor."""
    n = int(total * sr); tt = np.arange(n) / sr
    drone = np.zeros(n)
    for f, a in ((110.0, 1.0), (164.81, 0.6), (220.0, 0.5), (55.0, 0.5)):
        for h in range(1, 6):
            drone += (a / h ** 1.4) * np.sin(2 * np.pi * f * h * tt + h) * (0.75 + 0.25 * np.sin(2 * np.pi * (0.4 + h * 0.1) * tt))
    drone /= np.abs(drone).max()
    drone *= np.clip(tt / 1.5, 0, 1) * np.clip((total - tt) / 1.2, 0, 1)
    beat = np.zeros(n)
    for b in np.arange(0.5, total - 1, 0.75):
        i = int(b * sr); k = np.arange(int(0.3 * sr)) / sr
        x = np.sin(2 * np.pi * (80 + 40 * np.exp(-k * 30)) * k) * np.exp(-k * 14)
        beat[i:i + len(x)] += x[: n - i] * 0.5
    return (drone * 0.08 + beat * 0.05).astype(np.float32)

def write_wav(path, x, sr=SR):
    x = x / max(1.0, np.abs(x).max() / 0.95)
    with wave.open(path, "w") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr); w.writeframes((x * 32767).astype(np.int16).tobytes())
